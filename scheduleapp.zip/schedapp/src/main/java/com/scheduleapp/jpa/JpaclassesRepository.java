package com.scheduleapp.jpa;

import com.scheduleapp.model.classes;
import org.springframework.data.repository.CrudRepository;

public interface JpaclassesRepository extends CrudRepository<classes, Long> {
}