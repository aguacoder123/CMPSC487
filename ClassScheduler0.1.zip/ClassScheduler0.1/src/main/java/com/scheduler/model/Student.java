package com.scheduler.model;

public class Student {
}
