package com.scheduler.controller;

import com.scheduler.model.Course;
import com.scheduler.service.CourseService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class ClassDisplayController {

    private final CourseService courseService;

    public ClassDisplayController(CourseService courseService){
        this.courseService = courseService;
    }

    @GetMapping("/classDisplay")
    public String CourseDisplay(Model model) {
        List<Course> courses = courseService.getCourses();
        model.addAttribute("courses",courses);
        return "classDisplay";
    }
}
