package com.scheduleapp.controller;

import com.scheduleapp.model.classes;
import com.scheduleapp.service.ClassesService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class ClassDisplayController {

    private final ClassesService classService;

    public ClassDisplayController(ClassesService classService){
        this.classService = classService;
    }

    @GetMapping("/classDisplay")
    public String CourseDisplay(Model model) {
        List<classes> classlist = classService.getClasses();
        model.addAttribute("courses",classlist);
        return "classDisplay";
    }
}
