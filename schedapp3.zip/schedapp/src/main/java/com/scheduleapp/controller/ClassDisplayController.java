package com.scheduleapp.controller;

import com.scheduleapp.model.classes;
import com.scheduleapp.model.users;
import com.scheduleapp.service.ClassesService;
import com.scheduleapp.service.UsersService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


import java.util.List;
import java.util.Optional;

@Controller
public class ClassDisplayController {

    private final UsersService userService;
    private final ClassesService classService;

    public ClassDisplayController(UsersService userService, ClassesService classesService){
        this.classService = classesService;
        this.userService = userService;
    }

    @GetMapping("/classDisplay")
    public String CourseDisplay(Model model) {
        model.addAttribute("courses", classService.getClasses());
        return "classDisplay";
    }

    @GetMapping("/sort")
    public String displaysort(Model model, int param1){
        model.addAttribute("courses",classService.getSortedClasses(param1));

        return "classDisplay";
    }

    @GetMapping("/search")
    public String search(Model model,@RequestParam String param1, @RequestParam String param2,
                         @RequestParam(required = false) Optional<Integer> param3, @RequestParam(required = false) Optional<Integer> param4){
        int param3a = 0;
        int param4a = 0;
        if(param3.isPresent()){
            param3a = param3.get();
        }
        if(param4.isPresent()){
            param4a = param4.get();
        }
        model.addAttribute("courses",classService.getSearchClasses(param1, param2, param3a,param4a,"00000000"));

        return "classDisplay";
    }

    @GetMapping("/enroll/{course_ID}")
    public String enroll(Model model,@PathVariable String course_ID){
        //attempts to add course to users list
        if(userService.addCourse("00000000",course_ID)){
            //if successful, updates the course
            classService.addUser("00000000", course_ID);
        }
        return "redirect:/classDisplay";
    }

    @GetMapping("/delclass/{class_ID}")
    public String delclass(@PathVariable String class_ID){
        List<users> students = userService.getStudents(class_ID);
        for(users student : students){
            userService.removeClass(student.getUser_ID(),class_ID);
        }
        classService.deleteClass(class_ID);
        return "redirect:/admin";
    }

    @GetMapping("/admin")
    public String admindisplay(Model model){
            model.addAttribute("courses", classService.getClasses());
            return "admin";
    }
    @GetMapping("/asort")
    public String displayasort(Model model, int param1){
        model.addAttribute("courses",classService.getSortedClasses(param1));

        return "admin";
    }

    @GetMapping("/asearch")
    public String asearch(Model model,@RequestParam String param1, @RequestParam String param2,
                         @RequestParam(required = false) Optional<Integer> param3, @RequestParam(required = false) Optional<Integer> param4){
        int param3a = 0;
        int param4a = 0;
        if(param3.isPresent()){
            param3a = param3.get();
        }
        if(param4.isPresent()){
            param4a = param4.get();
        }
        model.addAttribute("courses",classService.getSearchClasses(param1, param2, param3a,param4a,"00000000"));

        return "admin";
    }
}
