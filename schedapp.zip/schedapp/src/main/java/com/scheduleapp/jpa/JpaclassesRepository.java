package com.scheduleapp.jpa;

import com.scheduleapp.model.classes;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;


public interface JpaclassesRepository extends CrudRepository<classes, Long> {

    @Query(value = "select c FROM classes c where classes.class_ID = :id", nativeQuery = true)
    classes scheduleclass(@Param("id") String id);
}