package com.scheduler.model;

public class Course {
    private String classID;
    private String courseID;
    private String semester;
    private int capacity;
    private int slotsTaken;
    private String professor;
    private String students;
    private String courseTitle;
    private String department;
    private String description;
    private int credits;
    private String req1;
    private String req2;
    private String coreq;

    public Course(String classID, String courseID, String semester, int capacity, int slotsTaken, String professor, String students, String courseTitle, String department, String description, int credits, String req1, String req2, String coreq) {
        this.classID = classID;
        this.courseID = courseID;
        this.semester = semester;
        this.capacity = capacity;
        this.slotsTaken = slotsTaken;
        this.professor = professor;
        if(students == null){
            this.students = "";
        }else {
            this.students = students;
        }
        this.courseTitle = courseTitle;
        this.department = department;
        this.description = description;
        this.credits = credits;
        if(req1 == null){
            this.req1 = "none";
        }else{
            this.req1 = req1;
        }
        if(req2 == null){
            this.req2 = "none";
        }else{
            this.req2 = req2;
        }
        if(coreq == null){
            this.coreq = "none";
        }else{
            this.coreq = coreq;
        }
    }

    public String getClassID() {
        return classID;
    }

    public void setClassID(String classID) {
        this.classID = classID;
    }

    public String getCourseID() {
        return courseID;
    }

    public void setCourseID(String courseID) {
        this.courseID = courseID;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getSlotsTaken() {
        return slotsTaken;
    }

    public void setSlotsTaken(int slotsTaken) {
        this.slotsTaken = slotsTaken;
    }

    public String getProfessor() {
        return professor;
    }

    public void setProfessor(String professor) {
        this.professor = professor;
    }

    public String getStudents() {
        return students;
    }

    public void setStudents(String students) {
        this.students = students;
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public String getReq1() {
        return req1;
    }

    public void setReq1(String req1) {
        this.req1 = req1;
    }

    public String getReq2() {
        return req2;
    }

    public void setReq2(String req2) {
        this.req2 = req2;
    }

    public String getCoreq() {
        return coreq;
    }

    public void setCoreq(String coreq) {
        this.coreq = coreq;
    }
}
