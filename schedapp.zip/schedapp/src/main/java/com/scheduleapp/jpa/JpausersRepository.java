package com.scheduleapp.jpa;

import com.scheduleapp.model.users;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface JpausersRepository extends CrudRepository<users,Long> {

    @Query(value = "SELECT classes FROM schedules WHERE schedules.student_ID = :id",nativeQuery = true)
    String findclassString(@Param("id") String id);
}
