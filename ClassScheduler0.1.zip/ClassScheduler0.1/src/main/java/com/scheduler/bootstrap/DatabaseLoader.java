package com.scheduler.bootstrap;


import com.scheduler.model.Course;
import com.scheduler.repository.CourseRepository;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

@Component
public class DatabaseLoader implements ApplicationListener<ContextRefreshedEvent>{

    private final CourseRepository courseRepository;

    public DatabaseLoader(CourseRepository courseRepository){
        this.courseRepository = courseRepository;
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        try{
            Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/487w",
                    "root", "root");
            Statement stmt = connect.createStatement();
            ResultSet rs = stmt.executeQuery("Select * from classes left join " +
                    "courses on classes.course_ID = courses.course_ID;");
            while(rs.next()){
                Course course = new Course(rs.getString("class_ID"),rs.getString("course_ID"),
                        rs.getString("semester"),rs.getInt("capacity"),rs.getInt("slots_taken"),
                        rs.getString("professor"),rs.getString("students"),rs.getString("course_title"),
                        rs.getString("department"), rs.getString("description"), rs.getInt("credits"),
                        rs.getString("prereq1"),rs.getString("prereq2"),rs.getString("corequisite"));
                this.courseRepository.addCourse(course);
            }

        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}
