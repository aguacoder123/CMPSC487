package com.scheduleapp.repository;


import com.scheduleapp.jpa.JpaclassesRepository;
import com.scheduleapp.model.classes;
import com.scheduleapp.model.courses;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class ClassesRepository {

    private final JpaclassesRepository repository;

    public ClassesRepository(JpaclassesRepository repository){
        this.repository = repository;
    }

    public List<classes> getClasses(){
        return (List<classes>) repository.findAll();
    }


}
