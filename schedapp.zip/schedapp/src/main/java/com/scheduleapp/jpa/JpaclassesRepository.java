package com.scheduleapp.jpa;

import com.scheduleapp.model.classes;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;


public interface JpaclassesRepository extends CrudRepository<classes, Long> {

    @Query("select c FROM classes c where c.class_ID = :id")
    classes scheduleclass(@Param("id") String id);
}