package com.scheduler.repository;

import com.scheduler.model.Course;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class CourseRepository {

    private List<Course> courseList;

    public CourseRepository(){
        courseList = new ArrayList<>();
    }

    public List<Course> getCourses(){
        return courseList;
    }

    public Course addCourse(Course course){
        courseList.add(course);
        return course;
    }
}
