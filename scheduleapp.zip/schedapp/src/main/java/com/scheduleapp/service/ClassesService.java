package com.scheduleapp.service;
import com.scheduleapp.model.classes;
import com.scheduleapp.repository.ClassesRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClassesService {
    private final ClassesRepository classesRepository;

    public ClassesService(ClassesRepository classesRepository){
        this.classesRepository = classesRepository;
    }

    public List<classes> getClasses(){
        return classesRepository.getClasses();
    }

}
