package com.scheduleapp.controller;

import com.scheduleapp.model.classes;
import com.scheduleapp.service.ClassesService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import javax.websocket.server.PathParam;
import java.util.List;

@Controller
public class ClassDisplayController {

    private final ClassesService classService;

    public ClassDisplayController(ClassesService classService){
        this.classService = classService;
    }

    @GetMapping("/classDisplay")
    public String CourseDisplay(Model model) {
        List<classes> classlist = classService.getClasses();
        model.addAttribute("courses",classlist);
        return "classDisplay";
    }
    @GetMapping("/sort")
    public String displaysort(Model model, @RequestParam int param1){
        List<classes> classList = classService.getSortedClasses(param1);
        model.addAttribute("courses",classList);
        return "classDisplay";
    }

}
